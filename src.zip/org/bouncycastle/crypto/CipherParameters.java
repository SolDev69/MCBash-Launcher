package org.bouncycastle.crypto;

public interface CipherParameters {
}
