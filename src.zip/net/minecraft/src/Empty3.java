package net.minecraft.src;

class Empty3 {
}
