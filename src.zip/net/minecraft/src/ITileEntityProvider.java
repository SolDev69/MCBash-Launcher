package net.minecraft.src;

public interface ITileEntityProvider {
   TileEntity createNewTileEntity(World var1);
}
