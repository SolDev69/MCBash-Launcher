package net.minecraft.src;

public class BiomeGenOcean extends BiomeGenBase {
   public BiomeGenOcean(int par1) {
      super(par1);
      this.spawnableCreatureList.clear();
   }
}
